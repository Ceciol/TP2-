# settings 
import pygame

powerupImg = {}
powerupImg["slow"] = pygame.image.load("image/slow.png")
powerupImg["color"] = pygame.image.load("image/color.png")
powerupImg["goldCoin"] = pygame.image.load('image/coin_gold.png')
#powerupImg["free"] = pygame.image.load("image/free.png")

poweruptime = 5000

# colors 
red = (212,95,74)
